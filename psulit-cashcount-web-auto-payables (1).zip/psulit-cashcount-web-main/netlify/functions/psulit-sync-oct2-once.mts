const ID="1_msQClr0yfx_jTKeEfop6lnfNvBPd-sNNMkgLnBgsrU";
const ALL_DATA=[
{d:"2026-09-23",t:"09/23/2026 10:49:06",r:"PSC-MUDI7ZNG-VN9A",s:"Morning",ct:"Opening",tel:"Irene Maligat",fx:{PHP:324307.59,USD:14255,JPY:90000,EUR:100,AUD:100,CHF:30,TWD:35300},h:96172.10,bank:{PHP:50000,USD:500},rec:[["8Ventures","PHP",1000000]],gt:1334599.60,ft:1334599.60},
{d:"2026-09-23",t:"09/23/2026 20:16:50",r:"PSC-MUE2I3K3-GFHX",s:"Night",ct:"Opening",tel:"Joan Legaspi",fx:{PHP:502740.69,USD:11265,SGD:500,EUR:100,AUD:600,TWD:36400,CHF:30,HKD:80},h:96272.10,bank:{PHP:50000,USD:500},rec:[["8Ventures","PHP",1000000]],gt:1339989.35,ft:1339989.35},
{d:"2026-09-23",t:"09/23/2026 20:35:11",r:"PSC-MUE35PK3-EHRD",s:"Morning",ct:"Closing",tel:"Irene Maligat",fx:{PHP:502740.69,USD:11265,SGD:500,EUR:100,AUD:600,TWD:36400,CHF:30,HKD:80},h:96272.10,bank:{PHP:50000,USD:500},rec:[["8Ventures","PHP",1000000]],gt:1339989.35,ft:1339989.35},
{d:"2026-09-24",t:"09/24/2026 04:44:20",r:"PSC-MUEKMQVJ-90CI",s:"Night",ct:"Closing",tel:"Joan Legaspi",fx:{PHP:335548.09,USD:13945,SGD:500,HKD:80,AUD:600,EUR:100,TWD:36400,CHF:30},h:96272.10,bank:{PHP:50000,USD:500},rec:[["8Ventures","PHP",1000000]],gt:1340296.75,ft:1340296.75},
{d:"2026-09-24",t:"09/24/2026 11:28:10",r:"PSC-MUEZ23F0-56UA",s:"Morning",ct:"Opening",tel:"Irene Maligat",fx:{PHP:335548.09,USD:13945,HKD:80,EUR:100,CHF:30,SGD:500,AUD:600,TWD:36400},h:96272.10,bank:{PHP:50000,USD:500},rec:[["8Ventures","PHP",1000000]],ft:1345501.05},
{d:"2026-09-24",t:"09/24/2026 19:59:28",r:"PSC-MUFHBM08-4GRU",s:"Morning",ct:"Closing",tel:"Irene Maligat",fx:{PHP:677844.43,USD:9125,HKD:3080,CHF:20,TWD:36400,EUR:100,AUD:600,SGD:500},h:96272.10,bank:{PHP:50000,USD:500},rec:[["8Ventures","PHP",1000000]],ft:1407895.16},
{d:"2026-09-24",t:"09/24/2026 20:15:41",r:"PSC-MUFHWHFS-YB0N",s:"Night",ct:"Opening",tel:"Angelica Besid",fx:{PHP:677844.43,USD:9125,SGD:500,AUD:600,EUR:100,TWD:36400,CHF:30,HKD:3080},h:96272.10,bank:{PHP:50000,USD:500},rec:[["8Ventures","PHP",1000000]],ft:1408652.73},
{d:"2026-09-25",t:"09/25/2026 04:21:40",r:"PSC-MUFZ9GMS-HBZ9",s:"Night",ct:"Closing",tel:"Angelica Besid",fx:{PHP:384235.43,USD:13825,HKD:3080,CHF:30,TWD:36400,EUR:100,AUD:600,SGD:500},h:96272.10,bank:{PHP:50000,USD:500},rec:[["8Ventures","PHP",1000000]],ft:1410641.22},
{d:"2026-09-25",t:"09/25/2026 10:44:22",r:"PSC-MUGCXM2U-IXCK",s:"Morning",ct:"Opening",tel:"Irene Maligat",fx:{PHP:384235.43,USD:13825,SGD:500,AUD:600,EUR:100,TWD:36400,CHF:30,HKD:3080},h:96272.10,bank:{PHP:50000,USD:500},rec:[["8Ventures","PHP",1000000]],ft:1410524.26},
{d:"2026-09-25",t:"09/25/2026 19:45:26",r:"PSC-MUGW9F5S-R2BE",s:"Morning",ct:"Closing",tel:"Irene Maligat",fx:{PHP:665371.58,USD:10000,EUR:600,GBP:5,JPY:10000,TWD:36400},h:96272.10,bank:{PHP:50000,USD:500},rec:[["8Ventures","PHP",1000000]],ft:1413320.20},
{d:"2026-09-25",t:"09/25/2026 19:53:58",r:"PSC-MUGWKEC4-KGJ0",s:"Night",ct:"Opening",tel:"Angelica Besid",fx:{PHP:665371.58,USD:10000,TWD:36400,JPY:10000,GBP:5,EUR:600},h:96272.10,bank:{PHP:50000,USD:500},rec:[["8Ventures","PHP",1000000]],ft:1413320.20},
{d:"2026-09-26",t:"09/26/2026 04:45:24",r:"PSC-MUFHJTS3-9XVB",s:"Night",ct:"Closing",tel:"Angelica Besid",fx:{PHP:474503.88,USD:11940,JPY:10000,TWD:36400,KRW:1400000,EUR:800,GBP:5,THB:1300},h:96272.10,bank:{PHP:50000,USD:500},rec:[["8Ventures","PHP",1000000]],ft:1425468.98},
{d:"2026-09-26",t:"09/26/2026 09:16:57",r:"PSC-MUHP91F7-68P4",s:"Morning",ct:"Opening",tel:"Irene Maligat",fx:{PHP:474503.88,USD:11940,GBP:5,EUR:800,KRW:1400000,TWD:36400,JPY:10000,THB:1300},h:96272.10,bank:{PHP:50000,USD:500},rec:[["8Ventures","PHP",1000000]],ft:1420852.63},
{d:"2026-09-26",t:"09/26/2026 17:54:15",r:"PSC-MUI7QAAJ-9DZI",s:"Morning",ct:"Closing",tel:"Irene Maligat",fx:{PHP:1051364.08,USD:100,THB:1300,JPY:10000,TWD:36400,KRW:1400000,EUR:800,GBP:5,CNY:5300,SGD:1000,CAD:100},bank:{PHP:50000,USD:500},rec:[["8Ventures","PHP",1000000],["MB","PHP",63560.30]],ft:1360689.92},
{d:"2026-09-26",t:"09/26/2026 19:25:30",r:"PSC-MUIAZMUR-3JMD",s:"Mid-Shift",ct:"Closing",tel:"Cristina Mirang",fx:{PHP:1051364.08,USD:100,SGD:1000,EUR:820,CNY:5300,THB:1300,JPY:10000,TWD:36400,KRW:1400000,GBP:5,CAD:100},bank:{PHP:50000,USD:500},rec:[["8Ventures","PHP",1000000],["MB","PHP",63560.30]],ft:1362118.49},
{d:"2026-09-26",t:"09/26/2026 20:03:56",r:"PSC-MUICD2GC-QIAI",s:"Night",ct:"Opening",tel:"Angelica Besid",fx:{PHP:1051364.08,USD:100,CAD:100,GBP:5,KRW:1400000,TWD:36400,JPY:10000,THB:1300,CNY:5300,SGD:1000,EUR:800},bank:{PHP:50000,USD:500},rec:[["8Ventures","PHP",1000000],["MB","PHP",63560.30]],ft:1360689.92},
{d:"2026-09-27",t:"09/27/2026 04:34:38",r:"PSC-MUIULU3L-6PMQ",s:"Night",ct:"Closing",tel:"Angelica Besid",fx:{PHP:844174.08,USD:3100,JPY:10000,CAD:600,EUR:800,SGD:1000,CNY:5300,THB:1300,TWD:36400,GBP:5,KRW:1400000},bank:{PHP:50000,USD:500},rec:[["8Ventures","PHP",1000000],["MB","PHP",63560.30]],ft:1363123.82},
{d:"2026-09-27",t:"09/27/2026 08:47:31",r:"PSC-MUJ3N1JG-C2Q7",s:"Morning",ct:"Opening",tel:"Irene Maligat",fx:{PHP:844174.08,USD:3100,JPY:10000,CAD:600,GBP:5,EUR:800,SGD:1000,THB:1300,CNY:5300,TWD:36400,KRW:1400000},bank:{PHP:50000,USD:500},rec:[["8Ventures","PHP",1000000],["MB","PHP",63560.30]],ft:1363123.82},
{d:"2026-09-27",t:"09/27/2026 17:41:58",r:"PSC-MUJMQCZB-2BZ5",s:"Morning",ct:"Closing",tel:"Irene Maligat",fx:{PHP:509804.34,USD:9414,KRW:1400000,TWD:36400,CNY:5300,THB:1300,SGD:1000,GBP:5,CAD:600,JPY:10000},bank:{PHP:50000,USD:500},rec:[["8Ventures","PHP",1000000],["MB","PHP",63560.30]],ft:1366236.22},
{d:"2026-09-27",t:"09/27/2026 19:25:26",r:"PSC-MUJQFF38-809H",s:"Mid-Shift",ct:"Closing",tel:"Cristina Mirang",fx:{PHP:447694.34,USD:10414,GBP:25,JPY:10000,CAD:600,SGD:1000,KRW:1400000,THB:1300,TWD:36400,CNY:5300},bank:{PHP:50000,USD:500},rec:[["8Ventures","PHP",1000000],["MB","PHP",63560.30]],ft:1368279.11},
{d:"2026-09-27",t:"09/27/2026 19:45:14",r:"PSC-MUJR4VOT-0HOZ",s:"Night",ct:"Opening",tel:"Angelica Besid",fx:{PHP:447694.34,USD:10414,JPY:10000,GBP:5,CNY:5300,TWD:36400,THB:1300,KRW:1400000,SGD:1000,CAD:600},bank:{PHP:50000,USD:500},rec:[["8Ventures","PHP",1000000],["MB","PHP",63560.30]],ft:1366626.22},
{d:"2026-09-28",t:"09/28/2026 04:41:18",r:"PSC-MUKAA9H2-VZPG",s:"Night",ct:"Closing",tel:"Angelica Besid",fx:{PHP:335080.34,USD:11714,JPY:10000,CAD:600,GBP:5,AUD:100,EUR:400,CNY:5300,KRW:1400000,SGD:1000,THB:1300,TWD:36400},bank:{PHP:50000,USD:500},rec:[["8Ventures","PHP",1000000],["MB","PHP",63560.30]],ft:1368219.61},
{d:"2026-09-28",t:"09/28/2026 10:48:55",r:"PSC-MUKNF0E5-UUD8",s:"Morning",ct:"Opening",tel:"Joan Legaspi",fx:{PHP:335080.34,USD:11714,JPY:10000,CAD:600,GBP:5,AUD:100,EUR:400,CNY:5300,KRW:1400000,SGD:1000,THB:1300,TWD:36400},bank:{PHP:50000,USD:500},rec:[["8Ventures","PHP",1000000],["MB","PHP",63560.30]],ft:1367657.72},
{d:"2026-09-28",t:"09/28/2026 19:39:46",r:"PSC-MUL6DP4J-F8JF",s:"Morning",ct:"Closing",tel:"Joan Legaspi",fx:{PHP:371817.12,USD:12800,JPY:10000,HKD:20,CAD:1020,GBP:5,EUR:420,AUD:100,THB:3300,KRW:400000},bank:{PHP:50000,USD:500},rec:[["8Ventures","PHP",1000000],["MB","PHP",63560.30]],ft:1280253.17},
{d:"2026-09-28",t:"09/28/2026 20:01:56",r:"PSC-MUL767IL-QCM4",s:"Night",ct:"Opening",tel:"Angelica Besid",fx:{PHP:371817.12,USD:12800,JPY:10000,HKD:20,CAD:1020,GBP:5,EUR:4020,AUD:100,THB:3300,KRW:400000},bank:{PHP:50000,USD:500},rec:[["8Ventures","PHP",1000000],["MB","PHP",63560.30]],ft:1535572.31},
{d:"2026-09-29",t:"09/29/2026 04:27:06",r:"PSC-MULP7UI9-U5YJ",s:"Night",ct:"Closing",tel:"Angelica Besid",fx:{PHP:609849.08,USD:8800,JPY:10000,HKD:40,CAD:1020,GBP:5,EUR:402,AUD:100,THB:4940,KRW:640000},bank:{PHP:50000,USD:500},rec:[["8Ventures","PHP",1000000],["MB","PHP",63560.30]],ft:1281286.87},
{d:"2026-09-29",t:"09/29/2026 11:01:59",r:"PSC-MUM3B001-V03Z",s:"Morning",ct:"Opening",tel:"Joan Legaspi",fx:{PHP:609849.08,USD:8800,JPY:10000,HKD:20,CAD:1020,GBP:5,EUR:420,AUD:100,THB:4940,KRW:640000},bank:{PHP:50000,USD:500},rec:[["8Ventures","PHP",1000000],["MB","PHP",63560.30]],ft:1282103.85},
{d:"2026-09-29",t:"09/29/2026 19:41:15",r:"PSC-MUMLVGCY-G54O",s:"Morning",ct:"Closing",tel:"Joan Legaspi",fx:{PHP:718102.38,USD:8100,JPY:10000,HKD:20,CAD:1020,GBP:5,EUR:420,AUD:100,THB:4940,KRW:640000},h:99169.70,bank:{PHP:50000,USD:500},rec:[["8Ventures","PHP",1000000]],ft:1346607.15},
{d:"2026-09-29",t:"09/29/2026 20:01:37",r:"PSC-MUMMLNBV-EJML",s:"Night",ct:"Opening",tel:"Angelica Besid",fx:{PHP:718102.38,USD:8100,JPY:10000,GBP:5,EUR:420,AUD:100,THB:4940,KRW:640000,HKD:20,CAD:1020},h:99169.70,bank:{PHP:50000,USD:500},rec:[["8Ventures","PHP",1000000]],ft:1346607.15},
{d:"2026-09-30",t:"09/30/2026 04:34:24",r:"PSC-MUN4X34O-O3XR",s:"Night",ct:"Closing",tel:"Cristina Mirang",fx:{PHP:705668.38,USD:8300,JPY:10000,HKD:20,CAD:1020,GBP:5,KRW:640000,AUD:100,THB:4940,EUR:420},h:99169.70,bank:{PHP:50000,USD:500},rec:[["8Ventures","PHP",1000000]],ft:1346673.15},
{d:"2026-09-30",t:"09/30/2026 10:46:37",r:"PSC-MUN17RDI-8HW1",s:"Morning",ct:"Opening",tel:"Irene Maligat",fx:{PHP:705668.38,USD:8300,EUR:420,THB:4940,AUD:100,KRW:640000,GBP:5,CAD:1020,HKD:20,JPY:10000},h:99169.70,bank:{PHP:50000,USD:500},rec:[["8Ventures","PHP",1000000]],ft:1346863.00},
{d:"2026-09-30",t:"09/30/2026 19:52:50",r:"PSC-MUO1Q7B7-B2BT",s:"Morning",ct:"Closing",tel:"Irene Maligat",fx:{PHP:1075517.28,USD:2790,TWD:1000,HKD:20,CAD:1020,GBP:5,KRW:640000,AUD:100,THB:4940},h:99169.70,bank:{PHP:50000,USD:500},rec:[["8Ventures","PHP",1000000],["Barang.ai","PHP",12000]],ft:1340546.05},
{d:"2026-09-30",t:"09/30/2026 20:11:51",r:"PSC-MU02ENFP-41N0",s:"Night",ct:"Opening",tel:"Joan Legaspi",fx:{PHP:1075517.38,USD:2790,HKD:20,CAD:1020,GBP:5,AUD:100,THB:4940,TWD:1000,KRW:640000},h:99169.70,bank:{PHP:50000,USD:500},rec:[["8Ventures","PHP",1000000],["Barang.ai","PHP",12000]],ft:1340546.15},
{d:"2026-10-01",t:"10/01/2026 04:40:13",r:"PSC-MUOKKEV2-04V1",s:"Night",ct:"Closing",tel:"Joan Legaspi",fx:{PHP:421251.08,USD:13290,HKD:20,CAD:1020,GBP:5,SGD:10,AUD:100,THB:4940,TWD:1000,KRW:640000},h:99169.70,bank:{PHP:50000,USD:500},rec:[["8Ventures","PHP",1000000],["Barang.ai","PHP",12000]],ft:1343020.04},
{d:"2026-10-01",t:"10/01/2026 10:43:37",r:"PSC-MUOXJR15-151M",s:"Morning",ct:"Opening",tel:"Irene Maligat",fx:{PHP:421251.08,USD:13290,HKD:20,CAD:1020,GBP:5,SGD:10,AUD:100,THB:4940,TWD:1000,KRW:640000},h:99169.70,bank:{PHP:50000,USD:500},rec:[["8Ventures","PHP",1000000],["Barang.ai","PHP",12000]],ft:1348309.74},
{d:"2026-10-01",t:"10/01/2026 19:54:55",r:"PSC-MUPH8QI7-SIW1",s:"Morning",ct:"Closing",tel:"Irene Maligat",fx:{PHP:660013.16,USD:8913,HKD:5020,CAD:1020,GBP:5,SGD:20,AUD:100,THB:4940,TWD:1000,KRW:640000},h:99169.70,bank:{PHP:50000,USD:500},rec:[["8Ventures","PHP",1000000],["Barang.ai","PHP",12000]],ft:1352279.00},
{d:"2026-10-01",t:"10/01/2026 20:13:59",r:"PSC-MUPHX9EC-IK6Q",s:"Night",ct:"Opening",tel:"Angelica Besid",fx:{PHP:660013.16,USD:8913,HKD:5020,CAD:1020,GBP:5,SGD:20,AUD:100,THB:4940,KRW:640000,TWD:1000},h:99169.70,bank:{PHP:50000,USD:500},rec:[["8Ventures","PHP",1000000],["Barang.ai","PHP",12000]],ft:1352279.00},
{d:"2026-10-02",t:"10/02/2026 04:34:53",r:"PSC-MUPZTETJ-LABW",s:"Night",ct:"Closing",tel:"Angelica Besid",fx:{PHP:461299.76,USD:12013,TWD:1000,KRW:640000,THB:4940,AUD:100,SGD:20,GBP:5,CNY:600,HKD:5020,CAD:1020},h:99169.70,bank:{PHP:50000,USD:500},rec:[["8Ventures","PHP",1000000],["Barang.ai","PHP",12000]],ft:1354141.63},
{d:"2026-10-02",t:"10/02/2026 10:48:32",r:"PSC-MUQD5XNS-PGIR",s:"Morning",ct:"Opening",tel:"Irene Maligat",fx:{PHP:461299.76,USD:12013,CAD:1020,CNY:600,HKD:5020,GBP:5,SGD:20,AUD:100,TWD:1000,KRW:640000,THB:4940},h:99169.70,bank:{PHP:50000,USD:500},rec:[["8Ventures","PHP",1000000],["Barang.ai","PHP",12000]],ft:1354070.31},
{d:"2026-10-02",t:"10/02/2026 20:17:26",r:"PSC-MUQXHJPU-ER22",s:"Morning",ct:"Closing",tel:"Irene Maligat",fx:{PHP:823261.40,USD:6260,TWD:1000,JPY:12000,CAD:1020,CNY:4400,HKD:5020,VND:500000,THB:2300,AUD:120,SGD:20,GBP:5},h:99169.70,bank:{PHP:50000,USD:500},rec:[["8Ventures","PHP",1000000],["Barang.ai","PHP",12000]],ft:1362024.96},
{d:"2026-10-02",t:"10/02/2026 20:28:35",r:"PSC-MUQXVVD3-ZY9J",s:"Night",ct:"Opening",tel:"Angelica Besid",fx:{PHP:823261.40,USD:6260,JPY:12000,SGD:20,GBP:5,AUD:120,THB:2300,VND:500000,HKD:5020,CNY:4400,CAD:1020,TWD:1000},h:99169.70,bank:{PHP:50000,USD:500},rec:[["8Ventures","PHP",1000000],["Barang.ai","PHP",12000]],ft:1362024.96},
{d:"2026-10-02",t:"10/03/2026 04:55:46",r:"PSC-MURG045X-6356",s:"Night",ct:"Closing",tel:"Angelica Besid",fx:{PHP:474566.90,USD:6760,JPY:12000,SGD:6370,GBP:5,AUD:120,THB:2300,VND:500000,HKD:5020,CNY:4400,CAD:1220,TWD:1000},h:99169.70,bank:{PHP:50000,USD:500},rec:[["8Ventures","PHP",1000000],["Barang.ai","PHP",12000]],ft:1362024.96}
];
const slug=v=>String(v).toUpperCase().replace(/[^A-Z0-9]+/g,"-").replace(/^-|-$/g,"");
function businessDate_(stamp){
 const [datePart,timePart="00:00:00"]=String(stamp).trim().split(/\s+/);
 const [mm,dd,yyyy]=datePart.split("/").map(Number);
 const d=new Date(Date.UTC(yyyy,mm-1,dd));
 if(timePart < "05:00:00") d.setUTCDate(d.getUTCDate()-1);
 return d.toISOString().slice(0,10);
}
const DATA=ALL_DATA.filter(x=>businessDate_(x.t)<="2026-10-02");
function rows(x){
 const c={submittedAt:x.t,businessDate:businessDate_(x.t),branch:"Solaire",countType:x.ct,shift:x.s,teller:x.tel,reference:x.r,sourceApp:"Cash Count App"};
 const a=[]; const add=(k,f)=>a.push({syncKey:x.r+":"+k,...c,...f});
 for(const[k,v]of Object.entries(x.fx)) add("FOREX-"+slug(k),{category:"Forex Cash",currency:k,fundAccount:"Forex Drawer",amount:v,phpEquivalent:k==="PHP"?v:"",quantityUnits:"",notes:"Historical image backfill"});
 if(x.h!=null) add("FUND-HIVE",{category:"Fund Balance",currency:"PHP",fundAccount:"Hive",amount:x.h,phpEquivalent:x.h,quantityUnits:"",notes:"Historical image backfill"});
 if(x.bank) for(const[k,v]of Object.entries(x.bank)) add("BANK-"+slug(k),{category:"Bank Balance",currency:k,fundAccount:"BDO",amount:v,phpEquivalent:k==="PHP"?v:"",quantityUnits:"",notes:"Historical image backfill"});
 for(const[z,i]of (x.rec||[]).entries()) add("RECEIVABLE-"+slug(i[0])+"-"+z,{category:"Receivable",currency:i[1],fundAccount:i[0],amount:i[2],phpEquivalent:i[1]==="PHP"?i[2]:"",quantityUnits:"",notes:"Historical image backfill"});
 add("SUMMARY-FOREX-TOTAL",{category:"Summary",currency:"PHP",fundAccount:"Forex PHP Equivalent",amount:x.ft,phpEquivalent:x.ft,quantityUnits:"",notes:"Displayed report total; historical image backfill"});
 if(x.gt!=null) add("SUMMARY-GRAND-TOTAL",{category:"Summary",currency:"PHP",fundAccount:"Grand Total",amount:x.gt,phpEquivalent:x.gt,quantityUnits:"",notes:"Displayed report total; historical image backfill"});
 return a;
}
export default async()=>{
 const u=Netlify.env.get("CASH_COUNT_SHEET_WEBHOOK_URL"),s=Netlify.env.get("CASH_COUNT_WEBHOOK_SECRET");
 if(!u||!s) return new Response(JSON.stringify({ok:false,error:"bridge not configured"}),{status:500,headers:{"content-type":"application/json"}});
 const out=[];
 const allRows=DATA.flatMap(rows);
 const q=await fetch(u,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({
   eventType:"CASH_COUNT_SYNC",spreadsheetId:ID,branch:"Solaire",rows:allRows,secret:s
 })});
 const t=await q.text(); let j={}; try{j=JSON.parse(t)}catch{j={raw:t}};
 out.push({ref:"BATCH-SOLAIRE",status:q.status,result:j,rows:allRows.length});
 for (const branch of ["Solaire","Alphaland"]) {
   const q=await fetch(u,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({
     eventType:"CASH_COUNT_SYNC",spreadsheetId:ID,branch,rows:[],secret:s
   })});
   const t=await q.text(); let j={}; try{j=JSON.parse(t)}catch{j={raw:t}};
   out.push({ref:"SORT-"+branch,status:q.status,result:j,rows:0});
 }
 return new Response(JSON.stringify({ok:out.every(x=>x.status>=200&&x.status<300),count:DATA.length,totalRows:allRows.length,results:out}),{headers:{"content-type":"application/json"}});
};
export const config={path:"/__psulit-sync-solaire-backfill-20260923-1003"};